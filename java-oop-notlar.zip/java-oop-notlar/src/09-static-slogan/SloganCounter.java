/**
 * Static degisken kullanim ornegi
 * Her yeni Slogan olusturuldugunda sayac artar.
 */
public class SloganCounter {
    public static void main(String[] args) {
        Slogan obj;

        obj = new Slogan("Hak Hukuk Adalet");
        System.out.println(obj);

        obj = new Slogan("Tas devri degil hak devri");
        System.out.println(obj);

        obj = new Slogan("Susma sustukca sira sana gelecek");
        System.out.println(obj);

        obj = new Slogan("Korkma biziz, halk");
        System.out.println(obj);

        System.out.println();
        System.out.println("Toplam slogan sayisi: " + Slogan.getCount());
    }
}
