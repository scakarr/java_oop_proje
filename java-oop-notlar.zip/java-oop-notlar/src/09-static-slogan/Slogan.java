/**
 * Slogan sinifi
 * Static sayac ile toplam slogan sayisini tutar.
 * Static degisken tum nesneler arasinda paylasilir.
 */
public class Slogan {
    private String cumle;
    private static int sayac = 0; // Sinifa ait, tum nesneler ortak kullanir

    public Slogan(String str) {
        this.cumle = str;
        sayac++;
    }

    @Override
    public String toString() {
        return cumle;
    }

    public static int getCount() {
        return sayac;
    }
}
