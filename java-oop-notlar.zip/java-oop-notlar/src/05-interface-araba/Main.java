/**
 * Interface kullanim ornegi
 */
public class Main {
    public static void main(String[] args) {
        Araba arabam = new Araba();

        arabam.arabayiCalistir();
        arabam.vitesDurumu();
        arabam.vitesArttir();
        arabam.vitesDurumu();
        arabam.vitesAzalt();
        arabam.vitesDurumu();
        arabam.arabayiDurdur();
    }
}
