/**
 * IAraba interface'i
 * Araba siniflarinin uymasi gereken sozlesmeyi tanimlar.
 */
public interface IAraba {
    void arabayiCalistir();
    void arabayiDurdur();
    void vitesArttir();
    void vitesAzalt();
    void vitesDurumu();
}
