/**
 * Araba sinifi - IAraba interface'ini implement eder.
 */
public class Araba implements IAraba {
    private int vitesDegeri = 0;

    @Override
    public void arabayiCalistir() {
        System.out.println("Arac calistirildi.");
        vitesDegeri = 0;
    }

    @Override
    public void arabayiDurdur() {
        System.out.println("Araba durduruldu.");
        vitesDegeri = 0;
        System.out.println("Vites: " + vitesDegeri);
    }

    @Override
    public void vitesArttir() {
        vitesDegeri++;
        System.out.println("Vites artirildi: " + vitesDegeri);
    }

    @Override
    public void vitesAzalt() {
        vitesDegeri--;
        System.out.println("Vites azaltildi: " + vitesDegeri);
    }

    @Override
    public void vitesDurumu() {
        System.out.println("Su anki vites: " + vitesDegeri);
    }
}
