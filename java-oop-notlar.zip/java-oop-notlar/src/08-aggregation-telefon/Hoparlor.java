/**
 * Hoparlor sinifi
 * Telefon'dan bagimsiz olarak var olabilir (Aggregation).
 */
public class Hoparlor {
    private int guc;

    public Hoparlor(int guc) {
        this.guc = guc;
    }

    public int getGuc() {
        return guc;
    }
}
