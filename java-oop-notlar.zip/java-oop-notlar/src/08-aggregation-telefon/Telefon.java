/**
 * Telefon sinifi
 * Kamera ve Hoparlor icerir (Aggregation - has-a iliskisi).
 * Kamera ve Hoparlor kendi baslarina da var olabilir.
 */
public class Telefon {
    private Kamera kamera;
    private Hoparlor hoparlor;

    public Telefon(Kamera kamera, Hoparlor hoparlor) {
        this.kamera = kamera;
        this.hoparlor = hoparlor;
    }

    public void ozellikleriGoster() {
        System.out.println("Telefon Ozellikleri:");
        System.out.println("Kamera cozunurlugu: " + kamera.getCozunurluk() + " MP");
        System.out.println("Hoparlor gucu: " + hoparlor.getGuc() + " watt");
    }

    public static void main(String[] args) {
        Kamera kamera = new Kamera(64);
        Hoparlor hoparlor = new Hoparlor(10);

        Telefon telefon = new Telefon(kamera, hoparlor);
        telefon.ozellikleriGoster();
    }
}
