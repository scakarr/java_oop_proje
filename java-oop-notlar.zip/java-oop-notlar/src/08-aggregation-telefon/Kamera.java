/**
 * Kamera sinifi
 * Telefon'dan bagimsiz olarak var olabilir (Aggregation).
 */
public class Kamera {
    private int cozunurluk;

    public Kamera(int cozunurluk) {
        this.cozunurluk = cozunurluk;
    }

    public int getCozunurluk() {
        return cozunurluk;
    }
}
