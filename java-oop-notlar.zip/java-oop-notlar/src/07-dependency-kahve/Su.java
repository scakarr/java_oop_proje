/**
 * Su sinifi
 * KahveMakinesi tarafindan kullanilir (Dependency iliskisi).
 */
public class Su {
    private int miktar;

    public Su(int miktar) {
        this.miktar = miktar;
    }

    public int getMiktar() {
        return miktar;
    }
}
