/**
 * KahveMakinesi sinifi
 * Su nesnesine bagimlidir (Dependency).
 * Su, makinenin bir parcasi degildir; sadece gecici olarak gereklidir.
 */
public class KahveMakinesi {

    public void kahveYap(Su su) {
        if (su.getMiktar() > 0) {
            System.out.println("Kahve hazirlaniyor... " + su.getMiktar() + " ml su kullanildi.");
        } else {
            System.out.println("Yeterli su yok!");
        }
    }

    public static void main(String[] args) {
        KahveMakinesi makine = new KahveMakinesi();
        Su su = new Su(200); // 200 ml su verildi

        makine.kahveYap(su); // Kahve yapiliyor
    }
}
