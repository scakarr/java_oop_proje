/**
 * Yazilimci sinifi - Calisan'dan turetilmistir.
 * maasHesapla() metodu bonus ekleyerek override edilmistir.
 */
public class Yazilimci extends Calisan {
    private double bonus;

    public Yazilimci(String isim, double baseMaas, double bonus) {
        super(isim, baseMaas);
        this.bonus = bonus;
    }

    @Override
    public double maasHesapla() {
        return super.getBaseMaas() + bonus;
    }
}
