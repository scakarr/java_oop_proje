/**
 * Calisan (Calisan) ust sinifi
 * maasHesapla() metodu alt siniflarda override edilecektir.
 */
public class Calisan {
    private String isim;
    private double baseMaas;

    public Calisan(String isim, double baseMaas) {
        this.isim = isim;
        this.baseMaas = baseMaas;
    }

    public String getIsim() {
        return isim;
    }

    public double getBaseMaas() {
        return baseMaas;
    }

    // Override edilecek metot
    public double maasHesapla() {
        return baseMaas;
    }
}
