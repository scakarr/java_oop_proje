/**
 * Avukat sinifi - Calisan'dan turetilmistir.
 * maasHesapla() metodu avukat bonus'u ekleyerek override edilmistir.
 */
public class Avukat extends Calisan {
    private double avukatBonus;

    public Avukat(String isim, double baseMaas, double avukatBonus) {
        super(isim, baseMaas);
        this.avukatBonus = avukatBonus;
    }

    @Override
    public double maasHesapla() {
        return super.getBaseMaas() + avukatBonus;
    }
}
