import java.util.Scanner;

/**
 * Method Overriding (Metot Ezme) ornegi
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Yazilimci bonusunu girin: ");
        double yazilimciBonus = scanner.nextDouble();

        System.out.print("Avukat bonusunu girin: ");
        double avukatBonus = scanner.nextDouble();

        // Calisanlari olustur
        Calisan yazilimci = new Yazilimci("Ahmet", 10000, yazilimciBonus);
        Calisan avukat = new Avukat("Mehmet", 8000, avukatBonus);

        // Sonuclari yazdir
        System.out.println("\n--- Maaslar ---");
        System.out.println(yazilimci.getIsim() + " : " + yazilimci.maasHesapla());
        System.out.println(avukat.getIsim() + " : " + avukat.maasHesapla());

        scanner.close();
    }
}
