/**
 * Main sinifi - Person, Employee ve Company kullanim ornegi
 */
public class Main {
    public static void main(String[] args) {
        Company company = new Company();

        Employee e1 = new Employee("Ali", 30, 70000);
        Employee e2 = new Employee("Akin", 28, 60000);
        Employee e3 = new Employee("Aleyna", 34, 64000);
        Employee e4 = new Employee("Batu", 24, 58000);
        Employee e5 = new Employee("Hakan", 52, 152000);

        company.addEmployee(0, e1);
        company.addEmployee(1, e2);
        company.addEmployee(2, e3);
        company.addEmployee(3, e4);
        company.addEmployee(4, e5);

        double totalSalary = company.calculateTotalSalary();
        System.out.println("Verilen Toplam Maas : " + totalSalary);

        Employee oldest = company.findOldestEmployee();
        if (oldest != null) {
            System.out.println("En yasli calisan : " + oldest.getName() + ", Yasi : " + oldest.getAge());
        }
    }
}
