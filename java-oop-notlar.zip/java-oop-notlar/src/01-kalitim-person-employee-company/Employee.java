/**
 * Employee (Calisan) sinifi
 * Person sinifindan kalitim (extends) alir ve salary ozelligi ekler.
 */
public class Employee extends Person {
    private double salary;

    public Employee(String name, int age, double salary) {
        super(name, age); // Ust sinif constructor'i cagrilir
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
