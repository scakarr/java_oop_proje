/**
 * Company (Sirket) sinifi
 * Employee dizisi tutar.
 * addEmployee, calculateTotalSalary ve findOldestEmployee metotlari icerir.
 */
public class Company {
    private Employee[] employees = new Employee[5];

    public void addEmployee(int index, Employee emp) {
        if (index >= 0 && index < employees.length) {
            employees[index] = emp;
        }
    }

    public double calculateTotalSalary() {
        double total = 0;
        for (int i = 0; i < employees.length; i++) {
            if (employees[i] != null) {
                total += employees[i].getSalary();
            }
        }
        return total;
    }

    public Employee findOldestEmployee() {
        Employee oldest = null;
        for (int i = 0; i < employees.length; i++) {
            if (employees[i] != null) {
                if (oldest == null || employees[i].getAge() > oldest.getAge()) {
                    oldest = employees[i];
                }
            }
        }
        return oldest;
    }
}
