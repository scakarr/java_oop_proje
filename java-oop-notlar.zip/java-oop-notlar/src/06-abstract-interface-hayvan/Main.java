/**
 * Abstract Class + Interface birlikte kullanim ornegi
 * (Final sinavi cikmis soru)
 */
public class Main {
    public static void main(String[] args) {
        Sahip sahip = new Sahip("Ahmet");
        Kopek kopek = new Kopek("Karabas");
        Kedi kedi = new Kedi("Minnak");

        sahip.tanit();

        System.out.println("\n--- Kopek ---");
        kopek.sesCikar();
        kopek.oyna();
        kopek.sahipIleEtkiles();

        System.out.println("\n--- Kedi ---");
        kedi.sesCikar();
        kedi.oyna();
        kedi.sahipIleEtkiles();
    }
}
