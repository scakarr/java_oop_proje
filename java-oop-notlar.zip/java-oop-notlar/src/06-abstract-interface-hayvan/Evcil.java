/**
 * Evcil (Pet) interface'i
 * Sahiple etkilesim metodunu tanimlar.
 */
public interface Evcil {
    void sahipIleEtkiles();
}
