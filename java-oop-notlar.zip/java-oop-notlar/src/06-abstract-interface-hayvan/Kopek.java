/**
 * Kopek sinifi
 * Hem Hayvan'dan kalitim alir hem de Evcil interface'ini implement eder.
 */
public class Kopek extends Hayvan implements Evcil {

    public Kopek(String isim) {
        super(isim);
    }

    @Override
    public void sesCikar() {
        System.out.println(isim + " havliyor!");
    }

    @Override
    public void oyna() {
        System.out.println(isim + " top oynuyor!");
    }

    @Override
    public void sahipIleEtkiles() {
        System.out.println(isim + " sahibine sariliyor.");
    }
}
