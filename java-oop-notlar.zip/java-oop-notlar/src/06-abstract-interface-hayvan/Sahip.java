/**
 * Sahip (Owner) sinifi
 */
public class Sahip {
    private String ad;

    public Sahip(String ad) {
        this.ad = ad;
    }

    public void tanit() {
        System.out.println("Sahibin adi: " + ad);
    }
}
