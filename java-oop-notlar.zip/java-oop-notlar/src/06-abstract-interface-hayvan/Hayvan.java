/**
 * Soyut Hayvan sinifi
 * makeSound (sesCikar) ve play (oyna) soyut metotlardir.
 */
public abstract class Hayvan {
    protected String isim;

    public Hayvan(String isim) {
        this.isim = isim;
    }

    public abstract void sesCikar();
    public abstract void oyna();
}
