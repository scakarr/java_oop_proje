/**
 * Kedi sinifi
 * Hem Hayvan'dan kalitim alir hem de Evcil interface'ini implement eder.
 */
public class Kedi extends Hayvan implements Evcil {

    public Kedi(String isim) {
        super(isim);
    }

    @Override
    public void sesCikar() {
        System.out.println(isim + " miyavliyor!");
    }

    @Override
    public void oyna() {
        System.out.println(isim + " ip ile oynuyor!");
    }

    @Override
    public void sahipIleEtkiles() {
        System.out.println(isim + " sahibinin yanina kivriliyor.");
    }
}
