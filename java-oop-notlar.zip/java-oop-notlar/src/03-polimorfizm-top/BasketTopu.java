/**
 * Basketbol Topu - Top sinifindan turetilmistir.
 * skorArttir() metodu override edilmistir (polimorfizm).
 */
public class BasketTopu extends Top {
    private int havaBasinci;
    private int basketSayisi;

    public BasketTopu() {
        this.havaBasinci = 8; // sabit deger
        this.basketSayisi = 0;
    }

    public void basketOl() {
        basketSayisi++;
        System.out.println("Basket oldu! Toplam basket: " + basketSayisi);
    }

    @Override
    public void skorArttir() {
        basketOl();
    }
}
