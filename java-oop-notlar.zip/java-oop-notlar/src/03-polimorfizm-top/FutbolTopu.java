/**
 * Futbol Topu - Top sinifindan turetilmistir.
 */
public class FutbolTopu extends Top {
    private int agirlik;
    private int sayi;

    public FutbolTopu() {
        this.agirlik = 6; // sabit deger
        this.sayi = 0;
    }

    public void sayiKazan() {
        sayi++;
        System.out.println("Gol oldu! Toplam sayi: " + sayi);
    }

    @Override
    public void skorArttir() {
        sayiKazan();
    }
}
