import java.util.Scanner;

/**
 * Polimorfizm ornegi
 * Kullanici secimine gore farkli top nesneleri olusturulur
 * ve ayni skorArttir() metodu farkli davranislar gosterir.
 */
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Top top = null;

        System.out.println("Hangi topu kullanmak istiyorsunuz?");
        System.out.println("1 - Basket Topu");
        System.out.println("2 - Voleybol Topu");
        System.out.println("3 - Futbol Topu");
        System.out.print("Seciminiz: ");

        int secim = input.nextInt();

        switch (secim) {
            case 1:
                top = new BasketTopu();
                break;
            case 2:
                top = new VoleybolTopu();
                break;
            case 3:
                top = new FutbolTopu();
                break;
            default:
                System.out.println("Gecersiz secim!");
                input.close();
                return;
        }

        // Polimorfik cagri - calisma zamaninda hangi sinifin metodu cagrilacagi belirlenir
        top.skorArttir();

        input.close();
    }
}
