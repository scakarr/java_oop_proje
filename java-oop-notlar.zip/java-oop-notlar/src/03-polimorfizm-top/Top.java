/**
 * Ust sinif (Base Class)
 * skorArttir() metodu polimorfik olarak override edilecektir.
 */
public class Top {
    public void skorArttir() {
        System.out.println("Genel top skoru artirildi.");
    }
}
