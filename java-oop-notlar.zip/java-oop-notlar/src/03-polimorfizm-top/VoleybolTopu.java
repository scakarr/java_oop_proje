/**
 * Voleybol Topu - Top sinifindan turetilmistir.
 */
public class VoleybolTopu extends Top {
    private int agirlik;
    private int golSayisi;

    public VoleybolTopu() {
        this.agirlik = 5; // sabit deger
        this.golSayisi = 0;
    }

    public void golOl() {
        golSayisi++;
        System.out.println("Sayi kazandiniz! Toplam gol: " + golSayisi);
    }

    @Override
    public void skorArttir() {
        golOl();
    }
}
