/**
 * Daire sinifi - Sekil soyut sinifindan turetilmistir.
 */
public class Daire extends Sekil {
    private double yariCap;

    public Daire(double yariCap) {
        super("Daire");
        this.yariCap = yariCap;
    }

    @Override
    public double alanHesapla() {
        return Math.PI * yariCap * yariCap;
    }
}
