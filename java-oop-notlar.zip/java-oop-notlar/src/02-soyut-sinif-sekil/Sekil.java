/**
 * Soyut sinif (Abstract Class) ornegi
 * alanHesapla() metodu soyut oldugu icin alt siniflarda override edilmek zorundadir.
 */
public abstract class Sekil {
    protected String ad;

    public Sekil(String ad) {
        this.ad = ad;
    }

    // Soyut metot - alt siniflarda mutlaka implement edilmeli
    public abstract double alanHesapla();

    public void bilgileriGoster() {
        System.out.println("Sekil: " + ad);
        System.out.println("Alan: " + alanHesapla());
    }
}
