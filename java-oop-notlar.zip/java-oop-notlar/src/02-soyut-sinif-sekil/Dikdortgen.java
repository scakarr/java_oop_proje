/**
 * Dikdortgen sinifi - Sekil soyut sinifindan turetilmistir.
 */
public class Dikdortgen extends Sekil {
    private double genislik;
    private double yukseklik;

    public Dikdortgen(double genislik, double yukseklik) {
        super("Dikdortgen");
        this.genislik = genislik;
        this.yukseklik = yukseklik;
    }

    @Override
    public double alanHesapla() {
        return genislik * yukseklik;
    }
}
