/**
 * Soyut sinif kullanimi ornegi
 */
public class Main {
    public static void main(String[] args) {
        Sekil s1 = new Daire(5);
        Sekil s2 = new Dikdortgen(4, 6);

        s1.bilgileriGoster();
        System.out.println("-----------------");
        s2.bilgileriGoster();
    }
}
