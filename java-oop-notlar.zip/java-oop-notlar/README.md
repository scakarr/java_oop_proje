# Java Nesne Yönelimli Programlama (OOP) Çalışma Notları

Bu repository, üniversite Java dersi kapsamında hazırlanmış **Nesne Yönelimli Programlama** konu notlarını ve örnek kodları içermektedir.  
Tüm kodlar temizlenmiş, düzeltilmiş ve çalıştırılabilir hale getirilmiştir.

> **Not:** Bu çalışma notları final sınavına hazırlık amacıyla düzenlenmiştir.  
> Konular: Kalıtım, Soyut Sınıflar, Polimorfizm, Interface, Method Overriding, Sınıf İlişkileri (Dependency, Aggregation) ve Static kavramı.

---

## 📁 Proje Yapısı

```
java-oop-notlar/
├── README.md
├── .gitignore
└── src/
    ├── 01-kalitim-person-employee-company/     # Kalıtım + Encapsulation
    ├── 02-soyut-sinif-sekil/                   # Abstract Class
    ├── 03-polimorfizm-top/                    # Polymorphism
    ├── 04-method-overriding-calisan/          # Method Overriding
    ├── 05-interface-araba/                    # Interface
    ├── 06-abstract-interface-hayvan/          # Abstract + Interface (Final sorusu)
    ├── 07-dependency-kahve/                   # Dependency ilişkisi
    ├── 08-aggregation-telefon/                # Aggregation ilişkisi
    └── 09-static-slogan/                      # Static değişken ve metot
```

---

## 🚀 Nasıl Çalıştırılır?

Her klasör bağımsız bir örnektir. İstediğiniz klasöre girip şu komutlarla çalıştırabilirsiniz:

```bash
# Örnek: Person-Employee-Company
cd src/01-kalitim-person-employee-company
javac *.java
java Main
```

> Java 8 veya üzeri sürüm gereklidir.

---

## 📚 Konu Özetleri

### 1. Kalıtım (Inheritance) + Encapsulation
**Klasör:** `01-kalitim-person-employee-company`

- `Person` sınıfı: `name` ve `age` private tutulur (Encapsulation).
- `Employee` sınıfı `Person`'dan türetilir ve `salary` ekler.
- `Company` sınıfı 5 elemanlı `Employee` dizisi tutar.
- Metotlar: `addEmployee()`, `calculateTotalSalary()`, `findOldestEmployee()`.

**Önemli kavramlar:**
- `extends` anahtar kelimesi
- `super()` ile üst sınıf constructor çağrısı
- Getter / Setter

---

### 2. Soyut Sınıf (Abstract Class)
**Klasör:** `02-soyut-sinif-sekil`

- `Sekil` soyut sınıfı `alanHesapla()` soyut metoduna sahiptir.
- `Daire` ve `Dikdortgen` bu metodu override eder.
- Soyut sınıftan doğrudan nesne oluşturulamaz.

---

### 3. Polimorfizm (Polymorphism)
**Klasör:** `03-polimorfizm-top`

- `Top` üst sınıfında `skorArttir()` metodu tanımlıdır.
- `BasketTopu`, `VoleybolTopu`, `FutbolTopu` bu metodu **override** eder.
- Aynı metot çağrısı, çalışma zamanında farklı davranış gösterir (Runtime Polymorphism).

---

### 4. Method Overriding
**Klasör:** `04-method-overriding-calisan`

- `Calisan` sınıfında `maasHesapla()` metodu vardır.
- `Yazilimci` ve `Avukat` sınıfları bu metodu kendi bonuslarıyla override eder.
- `@Override` anotasyonu kullanılır.

---

### 5. Interface
**Klasör:** `05-interface-araba`

- `IAraba` interface'i 5 metot tanımlar.
- `Araba` sınıfı bu interface'i `implements` eder.
- Interface, "ne yapılacağını" söyler, "nasıl yapılacağını" söylemez.

---

### 6. Abstract Class + Interface Birlikte (Final Sorusu)
**Klasör:** `06-abstract-interface-hayvan`

- `Hayvan` → Abstract class (`sesCikar()`, `oyna()`)
- `Evcil` → Interface (`sahipIleEtkiles()`)
- `Kopek` ve `Kedi` hem abstract class'tan kalıtım alır hem interface'i implement eder.
- `Sahip` sınıfı bağımsızdır.

Bu örnek, **çoklu miras benzeri** davranışı interface sayesinde sağlar.

---

### 7. Dependency (Bağımlılık)
**Klasör:** `07-dependency-kahve`

- `KahveMakinesi` sınıfı `Su` nesnesini **geçici olarak** kullanır.
- Su, makinenin bir parçası değildir. Sadece ihtiyaç anında gereklidir.
- UML'de kesikli ok ile gösterilir.

---

### 8. Aggregation (Toplama / Bütün-Parça)
**Klasör:** `08-aggregation-telefon`

- `Telefon` sınıfı `Kamera` ve `Hoparlor` içerir (**has-a** ilişkisi).
- Kamera ve Hoparlör kendi başlarına da var olabilir.
- UML'de boş elmas (◇) ile gösterilir.

---

### 9. Static Değişken ve Metot
**Klasör:** `09-static-slogan`

- `Slogan` sınıfında `static int sayac` vardır.
- Her yeni nesne oluşturulduğunda sayaç artar.
- `getCount()` static metot olduğu için sınıf adı üzerinden çağrılır.

---

## 🧠 Önemli OOP Prensipleri (Kısa Hatırlatma)

| Prensip          | Açıklama |
|------------------|----------|
| **Encapsulation**| Veriyi private tutup getter/setter ile korumak |
| **Inheritance**  | `extends` ile üst sınıftan özellik almak |
| **Polymorphism** | Aynı metodun farklı sınıflarda farklı davranması |
| **Abstraction**  | Gereksiz detayları gizleyip sadece gerekli olanı göstermek |

---

## 📝 Sınıf İlişkileri Özeti

| İlişki          | Anlamı                          | Örnek |
|-----------------|----------------------------------|-------|
| **Inheritance** | A, B'nin bir türüdür (is-a)     | Köpek is-a Hayvan |
| **Aggregation** | A, B'ye sahiptir (has-a)        | Telefon has-a Kamera |
| **Dependency**  | A, B'yi kullanır (uses)         | KahveMakinesi uses Su |

---

## 📌 Notlar

- Tüm kodlar el yazısı notlardan ve çıkmış sorulardan derlenip **temizlenmiştir**.
- Aynı konudaki tekrarlayan / hatalı versiyonlar silinmiş, tek ve doğru versiyon bırakılmıştır.
- Kodlar Türkçe isimlendirme (yorum satırları) + İngilizce sınıf/metot isimleri ile tutarlı hale getirilmiştir.
- Final sınavında çıkan **Hayvan-Köpek-Kedi-Sahip** sorusu özel olarak temizlenip eklenmiştir.

---

## 🎓 Kullanım Amacı

Bu repository sadece **kişisel çalışma ve sınav hazırlığı** içindir.  
Başka öğrencilerin de faydalanması için açık kaynak olarak paylaşılmıştır.

İyi çalışmalar!

---

**Hazırlayan:** Üniversite öğrencisi  
**Ders:** Java / Nesne Yönelimli Programlama  
**Yıl:** 2026
